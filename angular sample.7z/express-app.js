var express = require("express");
var app = express();
var http = require("http");
var server = http.createServer(app);
var fs = require("fs");
var path = require("path");
var bodyParser = require("body-parser");

var products = [
	{ id: 1, name: "CD" },
	{ id: 2, name: "Movie" },
	{ id: 3, name: "Guitar" },
	{ id: 4, name: "Food" }
];

app.use(bodyParser.json());

app.get("/products/:id([0-9]+)", function (req, res) {
    var product = products.filter(function(product) { return product.id == req.params.id })[0];

    res.set("Content-type", "application/json");
    res.send(JSON.stringify(product));
});

app.get("/products", function(req, res) {
	res.set("Content-type", "application/json");
	res.send(JSON.stringify(products));
});

app.post("/products", function(req, res) {
	var product = req.body.data;
	product.id = products.length;

	products.push(product);

	res.set("Content-type", "application/json");
	res.send(JSON.stringify(product));
});

app.put("/products/:id", function(req, res) {
	var updatedData = req.body;

	var productToUpdate = products.filter(function(product) { return product.id == req.params.id })[0];
	productToUpdate.name = updatedData.name;

	res.set("Content-type", "application/json");
	res.send(JSON.stringify(productToUpdate));
});

app.get("/*", function(req, res) {
	var filePath = req.originalUrl;

	if(filePath === "/") 
		filePath = "./routing/index.html";
	else {
		filePath = "./routing" + filePath;
	}

	switch(path.extname(filePath)) {
		case ".html":
			res.set("Content-type", "text/html");
			break;

		case ".js":
			res.set("Content-type", "text/javascript");
			break;

		case ".css":
			res.set("Content-type", "text/css");
			break;

	}

	res.send(fs.readFileSync(filePath, "utf8"));
});

server.listen(8888, function () {
    console.log("Node server running on http://localhost:8888");
});